# Vangrapf CLI

Watch and download videos from YouTube, RuTube, VK, OK without blocks and ads.

## Usage

    vangrapf --watch <URL> [--cookies cookies.txt]
    vangrapf --download <URL> -o <directory>
    vangrapf --search "query" --watch --api-key <Ai..>

## Dependencies

- python3, yt-dlp, rich, requests, mpv (installed automatically)

## Report issues

https://github.com/vangrapf/vangrapf-cli
